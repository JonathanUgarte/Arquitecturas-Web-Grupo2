import data.CsvDataLoader;
import dto.ReporteCarreraDTO;
import entities.Carrera;
import entities.Estudiante;
import entities.Genero;
import repository.CarreraRepository;
import repository.EstudianteRepository;
import repository.JPAUtil;

import jakarta.persistence.EntityManager;
import java.util.List;

public class Main {
    public static void main(String[] args) {
        EntityManager em = JPAUtil.getEntityManager();
        EstudianteRepository estudianteRepo = new EstudianteRepository(em);
        CarreraRepository carreraRepo = new CarreraRepository(em);

        try {
            System.out.println("=== CARGA DE DATOS DESDE CSV ===");
            new CsvDataLoader(em).cargarTodo();

            System.out.println("\n=== 2.c ESTUDIANTES ORDENADOS POR APELLIDO/NOMBRE ===");
            estudianteRepo.obtenerTodosOrdenados().stream().limit(15)
                    .forEach(e -> System.out.println("- " + e.getApellido() + ", " + e.getNombres()));
            System.out.println("(se muestran los primeros 15)");

            System.out.println("\n=== 2.d BÚSQUEDA POR LIBRETA 250018 ===");
            Estudiante porLibreta = estudianteRepo.obtenerPorLibreta("250018");
            System.out.println("- " + porLibreta.getNombres() + " " + porLibreta.getApellido()
                    + " | DNI: " + porLibreta.getNumeroDocumento());

            System.out.println("\n=== 2.e ESTUDIANTES MASCULINOS ===");
            List<Estudiante> masculinos = estudianteRepo.obtenerPorGenero(Genero.MASCULINO);
            System.out.println("Cantidad: " + masculinos.size());
            masculinos.stream().limit(10)
                    .forEach(e -> System.out.println("- " + e.getNombres() + " " + e.getApellido()));

            System.out.println("\n=== 2.f CARRERAS ORDENADAS POR CANTIDAD DE INSCRIPTOS ===");
            List<Carrera> carreras = carreraRepo.obtenerCarrerasConInscriptosOrdenadas();
            for (Carrera c : carreras) {
                Long cantidad = em.createQuery(
                                "SELECT COUNT(i) FROM Inscripcion i WHERE i.carrera = :c", Long.class)
                        .setParameter("c", c)
                        .getSingleResult();
                System.out.println("- " + c.getNombre() + " -> " + cantidad + " inscriptos");
            }

            System.out.println("\n=== 2.g ESTUDIANTES DE TUDAI QUE VIVEN EN RAUCH ===");
            List<Estudiante> filtrados =
                    estudianteRepo.obtenerEstudiantesPorCarreraYCiudad("TUDAI", "Rauch");
            if (filtrados.isEmpty()) {
                System.out.println("- No hay resultados para ese filtro en los CSV.");
            } else {
                filtrados.forEach(e -> System.out.println("- " + e.getNombres() + " " + e.getApellido()));
            }

            System.out.println("\n=== 3. REPORTE DE CARRERAS POR AÑO ===");
            List<ReporteCarreraDTO> reporte = carreraRepo.generarReporteCarreras();
            reporte.forEach(r -> System.out.println("- " + r));

            System.out.println("\n=== FIN: CSV Y CONSULTAS PROBADOS ===");
        } catch (Exception e) {
            System.err.println("Error: " + e.getMessage());
            e.printStackTrace();
        } finally {
            if (em.isOpen()) em.close();
            JPAUtil.close();
        }
    }
}
