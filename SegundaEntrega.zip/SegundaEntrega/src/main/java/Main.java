import dto.ReporteCarreraDTO;
import entities.Carrera;
import entities.Estudiante;
import entities.Genero;
import entities.Inscripcion;
import repository.CarreraRepository;
import repository.EstudianteRepository;
import repository.JPAUtil;

import jakarta.persistence.EntityManager;
import java.util.List;

public class Main {

    public static void main(String[] args) {

        EntityManager em = JPAUtil.getEntityManager();

        EstudianteRepository estudianteRepo = new EstudianteRepository(em);
        CarreraRepository carreraRepo = new CarreraRepository(em);

        try {

            System.out.println("\n==================================================");
            System.out.println("     EJERCICIO INTEGRADOR - PRUEBA COMPLETA");
            System.out.println("==================================================");

            /*
             * ==========================================================
             * PUNTO 1 - CREACIÓN DEL MODELO
             * ==========================================================
             *
             * Estudiante:
             * nombres, apellido, edad, genero, documento,
             * ciudad y libreta.
             *
             * Carrera:
             * nombre.
             *
             * Inscripcion:
             * relaciona Estudiante <-> Carrera
             * y almacena año de inscripción y año de egreso.
             *
             * La antigüedad se calcula a partir del año de inscripción.
             * Si anioEgreso != null, el estudiante está graduado.
             */

            System.out.println("\n========== PUNTO 1 - CREANDO DATOS ==========");

            // ----------------------------------------------------------
            // CARRERAS
            // ----------------------------------------------------------

            Carrera tuari = crearCarrera(1, "TUARI");
            Carrera sistemas = crearCarrera(2, "Ingeniería de Sistemas");
            Carrera contador = crearCarrera(3, "Contador Público");

            em.getTransaction().begin();

            em.persist(tuari);
            em.persist(sistemas);
            em.persist(contador);

            em.getTransaction().commit();

            System.out.println("Carreras creadas:");
            System.out.println(" - " + tuari.getNombre());
            System.out.println(" - " + sistemas.getNombre());
            System.out.println(" - " + contador.getNombre());


            /*
             * ==========================================================
             * PUNTO 2.A
             * DAR DE ALTA ESTUDIANTES
             * ==========================================================
             */

            System.out.println("\n========== PUNTO 2.A - ALTA ESTUDIANTES ==========");

            Estudiante e1 = crearEstudiante(
                    1,
                    "Agustin",
                    "Pagola",
                    25,
                    Genero.MASCULINO,
                    "40111111",
                    "Tandil",
                    "1001"
            );

            Estudiante e2 = crearEstudiante(
                    2,
                    "Maria",
                    "Gomez",
                    22,
                    Genero.FEMENINO,
                    "40222222",
                    "Tandil",
                    "1002"
            );

            Estudiante e3 = crearEstudiante(
                    3,
                    "Juan",
                    "Perez",
                    27,
                    Genero.MASCULINO,
                    "40333333",
                    "Azul",
                    "1003"
            );

            Estudiante e4 = crearEstudiante(
                    4,
                    "Lucia",
                    "Fernandez",
                    24,
                    Genero.FEMENINO,
                    "40444444",
                    "Tandil",
                    "1004"
            );

            Estudiante e5 = crearEstudiante(
                    5,
                    "Pedro",
                    "Rodriguez",
                    29,
                    Genero.MASCULINO,
                    "40555555",
                    "Olavarria",
                    "1005"
            );

            estudianteRepo.guardarEstudiante(e1);
            estudianteRepo.guardarEstudiante(e2);
            estudianteRepo.guardarEstudiante(e3);
            estudianteRepo.guardarEstudiante(e4);
            estudianteRepo.guardarEstudiante(e5);

            System.out.println("✓ " + e1.getNombres() + " " + e1.getApellido());
            System.out.println("✓ " + e2.getNombres() + " " + e2.getApellido());
            System.out.println("✓ " + e3.getNombres() + " " + e3.getApellido());
            System.out.println("✓ " + e4.getNombres() + " " + e4.getApellido());
            System.out.println("✓ " + e5.getNombres() + " " + e5.getApellido());


            /*
             * ==========================================================
             * PUNTO 2.B
             * MATRICULAR ESTUDIANTES EN CARRERAS
             * ==========================================================
             *
             * Creamos manualmente las inscripciones para poder tener
             * diferentes años y comprobar correctamente el punto 3.
             */

            System.out.println("\n========== PUNTO 2.B - MATRICULACIONES ==========");

            em.getTransaction().begin();

            // AGUSTIN está en DOS carreras
            guardarInscripcion(em, e1, tuari, 2022, 2025);
            guardarInscripcion(em, e1, sistemas, 2023, null);

            // MARIA
            guardarInscripcion(em, e2, tuari, 2023, null);
            guardarInscripcion(em, e2, contador, 2024, null);

            // JUAN
            guardarInscripcion(em, e3, sistemas, 2022, 2024);

            // LUCIA
            guardarInscripcion(em, e4, tuari, 2024, null);
            guardarInscripcion(em, e4, sistemas, 2024, null);

            // PEDRO
            guardarInscripcion(em, e5, contador, 2022, 2025);

            em.getTransaction().commit();

            System.out.println("✓ Agustin -> TUARI (2022 - egresado 2025)");
            System.out.println("✓ Agustin -> Ingeniería de Sistemas (2023 - cursando)");
            System.out.println("✓ Maria -> TUARI (2023 - cursando)");
            System.out.println("✓ Maria -> Contador Público (2024 - cursando)");
            System.out.println("✓ Juan -> Ingeniería de Sistemas (2022 - egresado 2024)");
            System.out.println("✓ Lucia -> TUARI (2024 - cursando)");
            System.out.println("✓ Lucia -> Ingeniería de Sistemas (2024 - cursando)");
            System.out.println("✓ Pedro -> Contador Público (2022 - egresado 2025)");


            /*
             * ==========================================================
             * COMPROBACIÓN DEL PUNTO 1
             * ANTIGÜEDAD Y GRADUACIÓN
             * ==========================================================
             */

            System.out.println("\n========== PUNTO 1 - ANTIGÜEDAD / GRADUACIÓN ==========");

            List<Inscripcion> inscripciones =
                    em.createQuery(
                            "SELECT i FROM Inscripcion i " +
                                    "JOIN FETCH i.estudiante " +
                                    "JOIN FETCH i.carrera " +
                                    "ORDER BY i.estudiante.apellido",
                            Inscripcion.class
                    ).getResultList();

            for (Inscripcion i : inscripciones) {

                System.out.println(
                        i.getEstudiante().getApellido() + ", " +
                                i.getEstudiante().getNombres() +
                                " | Carrera: " + i.getCarrera().getNombre() +
                                " | Ingreso: " + i.getAnioInscripcion() +
                                " | Antigüedad: " + i.getAntiguedad() + " años" +
                                " | Graduado: " + (i.isGraduado() ? "SI" : "NO")
                );
            }


            /*
             * ==========================================================
             * PUNTO 2.C
             * TODOS LOS ESTUDIANTES ORDENADOS
             * ==========================================================
             */

            System.out.println("\n========== PUNTO 2.C - ESTUDIANTES ORDENADOS ==========");

            List<Estudiante> todos =
                    estudianteRepo.obtenerTodosOrdenados();

            for (Estudiante e : todos) {

                System.out.println(
                        e.getApellido() + ", " +
                                e.getNombres()
                );
            }


            /*
             * ==========================================================
             * PUNTO 2.D
             * BUSCAR POR LIBRETA UNIVERSITARIA
             * ==========================================================
             */

            System.out.println("\n========== PUNTO 2.D - BUSCAR POR LIBRETA ==========");

            Estudiante encontrado =
                    estudianteRepo.obtenerPorLibreta(1003);

            System.out.println(
                    "Libreta 1003 -> " +
                            encontrado.getNombres() + " " +
                            encontrado.getApellido()
            );


            /*
             * ==========================================================
             * PUNTO 2.E
             * ESTUDIANTES POR GÉNERO
             * ==========================================================
             */

            System.out.println("\n========== PUNTO 2.E - GÉNERO MASCULINO ==========");

            List<Estudiante> masculinos =
                    estudianteRepo.obtenerPorGenero(Genero.MASCULINO);

            for (Estudiante e : masculinos) {

                System.out.println(
                        " - " +
                                e.getNombres() + " " +
                                e.getApellido() +
                                " | " + e.getGenero()
                );
            }

            System.out.println("\n========== PUNTO 2.E - GÉNERO FEMENINO ==========");

            List<Estudiante> femeninos =
                    estudianteRepo.obtenerPorGenero(Genero.FEMENINO);

            for (Estudiante e : femeninos) {

                System.out.println(
                        " - " +
                                e.getNombres() + " " +
                                e.getApellido() +
                                " | " + e.getGenero()
                );
            }


            /*
             * ==========================================================
             * PUNTO 2.F
             * CARRERAS ORDENADAS POR CANTIDAD DE INSCRIPTOS
             * ==========================================================
             */

            System.out.println("\n========== PUNTO 2.F - CARRERAS POR INSCRIPTOS ==========");

            List<Carrera> carrerasOrdenadas =
                    carreraRepo.obtenerCarrerasConInscriptosOrdenadas();

            for (Carrera c : carrerasOrdenadas) {

                Long cantidad = em.createQuery(
                                "SELECT COUNT(i) FROM Inscripcion i " +
                                        "WHERE i.carrera.idCarrera = :id",
                                Long.class
                        )
                        .setParameter("id", c.getIdCarrera())
                        .getSingleResult();

                System.out.println(
                        c.getNombre() +
                                " -> " +
                                cantidad +
                                " inscriptos"
                );
            }


            /*
             * ==========================================================
             * PUNTO 2.G
             * ESTUDIANTES DE UNA CARRERA Y CIUDAD
             * ==========================================================
             */

            System.out.println("\n========== PUNTO 2.G - TUARI + TANDIL ==========");

            List<Estudiante> estudiantesTandil =
                    estudianteRepo.obtenerEstudiantesPorCarreraYCiudad(
                            "TUARI",
                            "Tandil"
                    );

            for (Estudiante e : estudiantesTandil) {

                System.out.println(
                        " - " +
                                e.getNombres() + " " +
                                e.getApellido() +
                                " | Ciudad: " +
                                e.getCiudadResidencia()
                );
            }


            /*
             * ==========================================================
             * PUNTO 3
             * REPORTE DE CARRERAS
             *
             * Carrera: orden alfabético
             * Año: orden cronológico
             * Cantidad de inscriptos
             * Cantidad de egresados
             * ==========================================================
             */

            System.out.println("\n==================================================");
            System.out.println(" PUNTO 3 - REPORTE DE INSCRIPTOS Y EGRESADOS");
            System.out.println("==================================================");

            List<ReporteCarreraDTO> reporte =
                    carreraRepo.generarReporteCarreras();

            String carreraAnterior = "";

            for (ReporteCarreraDTO r : reporte) {

                if (!r.getNombreCarrera().equals(carreraAnterior)) {

                    System.out.println(
                            "\nCARRERA: " +
                                    r.getNombreCarrera()
                    );

                    carreraAnterior = r.getNombreCarrera();
                }

                System.out.println(
                        "   Año: " + r.getAnio() +
                                " | Inscriptos: " + r.getInscriptos() +
                                " | Egresados: " + r.getEgresados()
                );
            }


            System.out.println("\n==================================================");
            System.out.println("       TODAS LAS PRUEBAS FINALIZARON");
            System.out.println("==================================================");

        } catch (Exception e) {

            System.err.println("\nERROR DURANTE LAS PRUEBAS:");
            System.err.println(e.getMessage());

            e.printStackTrace();

        } finally {

            if (em.isOpen()) {
                em.close();
            }

            JPAUtil.close();

            System.out.println("\nConexión cerrada.");
        }
    }


    /*
     * ==============================================================
     * MÉTODOS AUXILIARES
     * ==============================================================
     */

    private static Carrera crearCarrera(
            int id,
            String nombre
    ) {

        Carrera carrera = new Carrera();

        carrera.setIdCarrera(id);
        carrera.setNombre(nombre);

        return carrera;
    }


    private static Estudiante crearEstudiante(
            int id,
            String nombres,
            String apellido,
            int edad,
            Genero genero,
            String documento,
            String ciudad,
            String libreta
    ) {

        Estudiante estudiante = new Estudiante();

        estudiante.setIdEstudiante(id);
        estudiante.setNombres(nombres);
        estudiante.setApellido(apellido);
        estudiante.setEdad(edad);
        estudiante.setGenero(genero);
        estudiante.setNumeroDocumento(documento);
        estudiante.setCiudadResidencia(ciudad);
        estudiante.setNumeroLibretaUniversitaria(libreta);

        return estudiante;
    }


    private static void guardarInscripcion(
            EntityManager em,
            Estudiante estudiante,
            Carrera carrera,
            int anioInscripcion,
            Integer anioEgreso
    ) {

        Inscripcion inscripcion =
                new Inscripcion(
                        estudiante,
                        carrera,
                        anioInscripcion,
                        anioEgreso
                );

        em.persist(inscripcion);
    }
}